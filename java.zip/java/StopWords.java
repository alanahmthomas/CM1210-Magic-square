import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Driver {
    public static ArrayList<String> removeStopWords(String GTP3, String stopwords) throws IOException {
        ArrayList<String> wordlst = new ArrayList<String>();// to store words
        ArrayList<String> stopwordlst = new ArrayList<String>();// to store stop words

        // read file DTP3.txt
        BufferedReader br1 = new BufferedReader(new FileReader(GTP3));
        String line = "";
        // read line by line
        while ((line = br1.readLine()) != null) {
            // split line to words
            String[] words = line.split("[ ().!,:]");
            // add non space words to array list
            for (int i = 0; i < words.length; i++) {
                if (words[i].trim().equals("") == false) {
                    wordlst.add(words[i]);
                }
            }
        }
        br1.close();

        // convert words to upper case
        ArrayList<String> wordlstUpper = new ArrayList<String>();
        for (int i = 0; i < wordlst.size(); i++) {
            wordlstUpper.add(wordlst.get(i).toUpperCase());
        }

        // read file stopwords.txt
        BufferedReader br2 = new BufferedReader(new FileReader(stopwords));
        line = "";
        // read each line as word to arraylist
        while ((line = br2.readLine()) != null) {
            stopwordlst.add(line);
        }

        br2.close();

        for (int i = 0; i < stopwordlst.size(); i++) {
            // get last index of string stopwordlist.get(i) from wordlstUpper
            int lastindex = wordlstUpper.indexOf(stopwordlst.get(i).toUpperCase());
            while (lastindex != -1) {
                // get first index of string stopwordlist.get(i) from wordlstUpper
                int index = wordlstUpper.indexOf(stopwordlst.get(i).toUpperCase());
                // index!=-1 mean , string stopwordlist.get(i) found within wordlstUpper
                // then remove it
                if (index != -1) {
                    wordlst.remove(index);
                    wordlstUpper.remove(index);
                }
                // again , get last index of string stopwordlist.get(i) from wordlstUpper
                lastindex = wordlstUpper.indexOf(stopwordlst.get(i).toUpperCase());
            }
        }

        // return new non stop wordlist
        return wordlst;
    }

    public static void main(String[] args) {
        ArrayList<String> list = null;

        try {
            list = removeStopWords("GPT3.txt", "stopwords.txt");
        } catch (IOException e) {
            System.out.print("Error : " + e.getMessage());
        }

        // display word list
        System.out.println("Non Stop Words are----");
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }
    }
}
